create function fc_replaceStrAbbr(str varchar(1000))
  returns varchar(1000)
  BEGIN
DECLARE sstr VARCHAR(1000);
	SELECT  REPLACE(str, 'Saint ', 'St. ')  INTO sstr;
	RETURN sstr;
END;

