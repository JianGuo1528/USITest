create procedure proc_update_addr_tourico(IN tourico_country     varchar(32), IN destination_countryId int(3),
                                          IN destination_display int(2), IN destination_regionType varchar(32))
  BEGIN
 	IF destination_regionType = 'Multi-Region (within a country)' THEN
  		UPDATE
  			test.tourico_region_world,
  			hotel_test.destination
  		SET tourico_region_world.emulti_region_region_id = destination.desId
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND countryId = destination_countryId 
  		AND display = destination_display
  		AND fc_replaceStr(destination.desName) LIKE CONCAT(fc_replaceStr(REPLACE(tourico_region_world.city_name, 'St', 'Saint')), ',%')
  		AND destination.RegionType = 'Multi-Region (within a country)'
  		AND tourico_region_world.emulti_region_region_id IS NULL;
  		
  	ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
  		UPDATE
  			test.tourico_region_world,
  			hotel_test.destination
  		SET tourico_region_world.emulti_city_region_id = destination.desId
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND countryId = destination_countryId 
  		AND display = destination_display
  		AND fc_replaceStr(destination.desName) LIKE CONCAT(fc_replaceStr(REPLACE(tourico_region_world.city_name, 'St', 'Saint')), ',%')
  		AND destination.RegionType = 'Multi-City (Vicinity)'
  		AND tourico_region_world.emulti_city_region_id IS NULL;
  	
  	ELSEIF destination_regionType = 'City' THEN
  		UPDATE
  			test.tourico_region_world,
  			hotel_test.destination
  		SET tourico_region_world.ecity_region_id = destination.desId
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND countryId = destination_countryId 
  		AND display = destination_display
  		AND fc_replaceStr(destination.desName) LIKE CONCAT(fc_replaceStr(REPLACE(tourico_region_world.city_name, 'St', 'Saint')), ',%')
  		AND destination.RegionType = 'City'
  		AND tourico_region_world.ecity_region_id IS NULL;
  	
  	ELSE
  		UPDATE
  			test.tourico_region_world,
  			hotel_test.destination
  		SET tourico_region_world.eneighbor_region_id = destination.desId
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND countryId = destination_countryId 
  		AND display = destination_display
  		AND fc_replaceStr(destination.desName) LIKE CONCAT(fc_replaceStr(REPLACE(tourico_region_world.city_name, 'St', 'Saint')), ',%')
  		AND destination.RegionType = 'Neighborhood'
  		AND tourico_region_world.eneighbor_region_id IS NULL;
 	
  	END IF;

END;

