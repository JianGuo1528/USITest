CREATE PROCEDURE proc_destination_Destination_02(IN V_countryName VARCHAR(64))
  BEGIN

	DECLARE V_regionId int ;   
	DECLARE V_countryCode VARCHAR(64) ;   
	DECLARE V_countryId int ;   


	
	SELECT countryCode,countryId into V_countryCode,V_countryId  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

  SELECT regionId into V_regionId FROM `test`.`expedia_region_world` WHERE regionType = 'Country'  and regionName = V_countryName limit 1; 

 
 
 -- _priceline
 
update test.city_priceline 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null 
where city_priceline.countryId = V_countryId ;

 
update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display = 7
				and (city_priceline.city = destination.city or destination.city = concat(city_priceline.city,' (region)') )
				and destination.RegionType = 'Multi-Region (within a country)'
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.emulti_region_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;
 
 
 
 update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display = 7
				and (city_priceline.city = destination.city or destination.city = concat(city_priceline.city,' (and vicinity)') )
				and destination.RegionType = 'Multi-City (Vicinity)'
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.emulti_region_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;
 
update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display = 7
				and city_priceline.city = destination.city 
				and destination.RegionType = 'City' 
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.ecity_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;



update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display = 7
				and city_priceline.city = destination.city 
				and destination.RegionType = 'Neighborhood' 
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.ecity_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;






-- tourico_region ======================================================
-- tourico_region ======================================================
-- tourico_region ======================================================
update test.tourico_region_world 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null ,
 loc_emulti_city_region_id = null ,loc_ecity_region_id = null,  loc_eneighbor_region_id = null, loc_emulti_region_region_id= null ,ee_date = null 
WHERE `country` = V_countryName;


 -- ====================================================== tourico city
update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name from test.tourico_region_world where `country` = V_countryName group by city_id,destinationCode,city_name
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.city_name = destination.city or destination.city = concat(tourico_region_world.city_name,' (region)') )
		and destination.RegionType = 'Multi-Region (within a country)'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.emulti_region_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;


update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name from test.tourico_region_world where `country` = V_countryName group by city_id,destinationCode,city_name
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.city_name = destination.city or destination.city = concat(tourico_region_world.city_name,' (and vicinity)') )
		and destination.RegionType = 'Multi-City (Vicinity)'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.emulti_city_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;



update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name from test.tourico_region_world where `country` = V_countryName group by city_id,destinationCode,city_name
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.city_name = destination.city
		and destination.RegionType = 'City'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.ecity_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;
 

update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name from test.tourico_region_world where `country` = V_countryName group by city_id,destinationCode,city_name
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.city_name = destination.city
		and destination.RegionType = 'Neighborhood'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.eneighbor_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;

 -- ====================================================== tourico loc_

update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,desId,count(1)  from (
			select destinationId5,destinationCode,location from test.tourico_region_world where `country` = V_countryName group by destinationId5,destinationCode,location
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.location = destination.city or destination.city = concat(tourico_region_world.location,' (region)') )
		and destination.RegionType = 'Multi-Region (within a country)' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1


) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_emulti_region_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;


update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,desId,count(1)  from (
			select destinationId5,destinationCode,location from test.tourico_region_world where `country` = V_countryName group by destinationId5,destinationCode,location
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.location = destination.city or destination.city = concat(tourico_region_world.location,' (and vicinity)') )
		and destination.RegionType = 'Multi-City (Vicinity)' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_emulti_city_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;



update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,desId,count(1)  from (
			select destinationId5,destinationCode,location from test.tourico_region_world where `country` = V_countryName group by destinationId5,destinationCode,location
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.location = destination.city
		and destination.RegionType = 'City' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_ecity_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;
 

update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,desId,count(1)  from (
			select destinationId5,destinationCode,location from test.tourico_region_world where `country` = V_countryName group by destinationId5,destinationCode,location
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.location = destination.city
		and destination.RegionType = 'Neighborhood' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_eneighbor_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;
 
 
 
  
 
 
	 -- hotelbeds_map_zone_world ======================================================
	 -- hotelbeds_map_zone_world ======================================================
	 -- hotelbeds_map_zone_world ======================================================
	 -- hotelbeds_map_zone_world ======================================================
update test.hotelbeds_map_zone_world 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null ,
loc_emulti_city_region_id = null ,loc_ecity_region_id = null,  loc_eneighbor_region_id = null, loc_emulti_region_region_id= null,ee_date = null 
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world 
 inner join (
		 select destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId
		from  test.hotelbeds_map_zone_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_world.zoneName,' (region)')   or REPLACE (REPLACE(hotelbeds_map_zone_world.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and destination.RegionType = 'Multi-Region (within a country)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name and hotelbeds_map_zone_world.zoneName = aa.zoneName and hotelbeds_map_zone_world.zoneCode = aa.zoneCode
set hotelbeds_map_zone_world.loc_emulti_region_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world 
 inner join (
		 select destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId
		from  test.hotelbeds_map_zone_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_world.zoneName,' (and vicinity)')  or REPLACE (REPLACE(hotelbeds_map_zone_world.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and destination.RegionType = 'Multi-City (Vicinity)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name and hotelbeds_map_zone_world.zoneName = aa.zoneName and hotelbeds_map_zone_world.zoneCode = aa.zoneCode
set hotelbeds_map_zone_world.loc_emulti_city_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world 
 inner join (
		 select destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId
		from  test.hotelbeds_map_zone_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world.zoneName = destination.city   or REPLACE (REPLACE(hotelbeds_map_zone_world.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and destination.RegionType = 'City'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name and hotelbeds_map_zone_world.zoneName = aa.zoneName and hotelbeds_map_zone_world.zoneCode = aa.zoneCode
set hotelbeds_map_zone_world.loc_ecity_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world 
 inner join (
		 select destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId
		from  test.hotelbeds_map_zone_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world.zoneName = destination.city or REPLACE (REPLACE(hotelbeds_map_zone_world.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and destination.RegionType = 'Neighborhood'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,name,zoneName,hotelbeds_map_zone_world.zoneCode,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name and hotelbeds_map_zone_world.zoneName = aa.zoneName and hotelbeds_map_zone_world.zoneCode = aa.zoneCode
set hotelbeds_map_zone_world.loc_eneighbor_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



--   -------------------------------------------

 update test.hotelbeds_map_zone_world 
 inner join (
		select destinationPId,name,desId
		from  (
				select  destinationPId,name 
				from  test.hotelbeds_map_zone_world  
				WHERE `isoCode` = V_countryCode and name is not null 
				group by destinationPId,name
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.name = destination.city or destination.city = concat(kk.name,' (region)')   or REPLACE (REPLACE(kk.name,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and destination.RegionType = 'Multi-Region (within a country)'
		group by destinationPId,name,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name
set hotelbeds_map_zone_world.emulti_region_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world 
 inner join (
 		select destinationPId,name,desId
		from  (
				select  destinationPId,name 
				from  test.hotelbeds_map_zone_world  
				WHERE `isoCode` = V_countryCode and name is not null 
				group by destinationPId,name
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.name = destination.city or destination.city = concat(kk.name,' (and vicinity)') or REPLACE (REPLACE(kk.name,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Multi-City (Vicinity)'
		group by destinationPId,name,desId having count(1) = 1
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name
set hotelbeds_map_zone_world.emulti_city_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world 
 inner join (
  	select destinationPId,name,desId
		from  (
				select  destinationPId,name 
				from  test.hotelbeds_map_zone_world  
				WHERE `isoCode` = V_countryCode and name is not null 
				group by destinationPId,name
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.name = destination.city or REPLACE (REPLACE(kk.name,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'City'
		group by destinationPId,name,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name
set hotelbeds_map_zone_world.ecity_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world 
 inner join (
 
   	select destinationPId,name,desId
		from  (
				select  destinationPId,name 
				from  test.hotelbeds_map_zone_world  
				WHERE `isoCode` = V_countryCode and name is not null 
				group by destinationPId,name
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and ( kk.name = destination.city or REPLACE (REPLACE(kk.name,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Neighborhood'
		group by destinationPId,name,desId having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world.destinationPId = aa.destinationPId and hotelbeds_map_zone_world.name = aa.name
set hotelbeds_map_zone_world.eneighbor_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;

 


 
END;

