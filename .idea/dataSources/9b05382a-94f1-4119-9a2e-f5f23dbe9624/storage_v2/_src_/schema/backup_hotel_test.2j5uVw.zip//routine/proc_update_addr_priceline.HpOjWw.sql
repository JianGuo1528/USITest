CREATE PROCEDURE proc_update_addr_priceline(IN priceline_countryId INT(3), IN destination_countryId INT(3),
                                            IN destination_display INT(2), IN destination_regionType VARCHAR(32))
  BEGIN
	DECLARE region_style VARCHAR(64);
	
	IF destination_regionType = 'Multi-Region (within a country)' THEN
		SET region_style = 'test.city_priceline.emulti_region_region_id';
	ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
		SET region_style = 'test.city_priceline.emulti_city_region_id';
	ELSEIF destination_regionType = 'City' THEN
		SET region_style = 'test.city_priceline.ecity_region_id';
	ELSE
		SET region_style = 'test.city_priceline.eneighbor_region_id';
	END IF;
	
	SET @m_query = CONCAT('UPDATE
													test.city_priceline,
													hotel_test.destination 
												SET ', region_style, ' = destination.desId',
												' WHERE city_priceline.countryId = ', priceline_countryId, 
												'	AND destination.countryId = ', destination_countryId,
												' AND e_date IS NULL',
												' AND display = ', destination_display,
												' AND RegionType = \'', destination_regionType, '\''
												' AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(city_priceline.city), \',%\')',
												' AND ', region_style, ' IS NULL'
											);
	
	PREPARE stmt FROM @m_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @m_query2 = CONCAT('UPDATE 
													test.city_priceline,
													hotel_test.destination 
												SET ', region_style, ' = destination.desId',
												' WHERE city_priceline.countryId = ', priceline_countryId, 
												'	AND destination.countryId = ', destination_countryId,
												' AND e_date IS NULL',
												' AND display = ', destination_display,
												' AND RegionType = \'', destination_regionType, '\''
												' AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(city_priceline.state), \',%\')',
												' AND ', region_style, ' IS NULL'
											);
	
	PREPARE stmt2 FROM @m_query2;
	EXECUTE stmt2;
	DEALLOCATE PREPARE stmt2;

END;

