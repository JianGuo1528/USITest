CREATE PROCEDURE proc_destination_Map_Destination(IN V_countryName VARCHAR(64))
  BEGIN

	DECLARE V_regionId int ;   
	DECLARE V_countryCode VARCHAR(64) ;   
	DECLARE V_countryId int ;   


	SELECT countryCode,countryId into V_countryCode,V_countryId  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

  SELECT regionId into V_regionId FROM `test`.`expedia_region_world` WHERE regionType = 'Country'  and regionName = V_countryName limit 1; 


	


 INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId`,countryId,created_at )
 select distinct destination.desId,'Expedia', regionId,desName,RegionType,regionId as expedia_regionId,countryId,now()
 from hotel_test.destination where display = 7 and countryId = V_countryId;



INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Priceline',city_priceline.cityid_ppn, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from  test.city_priceline
inner join hotel_test.destination on destination.desId = city_priceline.emulti_city_region_id and destination.countryId = V_countryId and destination.display  =7 
where emulti_city_region_id is not null;

INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Priceline',city_priceline.cityid_ppn, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from  test.city_priceline
inner join hotel_test.destination on destination.desId = city_priceline.ecity_region_id and  destination.countryId = V_countryId and destination.display  = 7 
where ecity_region_id is not null;

INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Priceline',test.city_priceline.cityid_ppn, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from  test.city_priceline
inner join hotel_test.destination on destination.desId = city_priceline.eneighbor_region_id and destination.countryId = V_countryId and destination.display  =7 
where eneighbor_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Priceline',test.city_priceline.cityid_ppn, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from  test.city_priceline
inner join hotel_test.destination on destination.desId = city_priceline.emulti_region_region_id and destination.countryId = V_countryId and destination.display  =7 
where emulti_region_region_id is not null;


 
 
 
 
INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.loc_eneighbor_region_id and destination.countryId = V_countryId  and destination.display  =7
WHERE `isoCode` = V_countryCode and  loc_eneighbor_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.loc_ecity_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  loc_ecity_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.loc_emulti_city_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  loc_emulti_city_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.loc_emulti_region_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  loc_emulti_region_region_id is not null;


 -- =======================

INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.eneighbor_region_id and destination.countryId = V_countryId  and destination.display  =7
WHERE `isoCode` = V_countryCode and  eneighbor_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.ecity_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  ecity_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.emulti_city_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  emulti_city_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.hotelbeds_map_zone_world
inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world.emulti_region_region_id and destination.countryId = V_countryId and destination.display  =7
WHERE `isoCode` = V_countryCode and  emulti_region_region_id is not null;


-- ===================================================================================================
INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct distinct destination.desId,'Tourico',test.tourico_region_world.city_id, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.eneighbor_region_id and destination.countryId = V_countryId and destination.display  =7
where eneighbor_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct destination.desId,'Tourico',test.tourico_region_world.city_id, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.ecity_region_id and destination.countryId = V_countryId and destination.display  =7
where ecity_region_id is not null;

 

INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Tourico',test.tourico_region_world.city_id, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.emulti_city_region_id and destination.countryId = V_countryId and destination.display  =7
where emulti_city_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Tourico',test.tourico_region_world.city_id, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.emulti_region_region_id and destination.countryId = V_countryId and destination.display  =7
where emulti_region_region_id is not null;




-- ============================================================================================================
INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct distinct destination.desId,'Tourico',test.tourico_region_world.destinationId5, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.loc_eneighbor_region_id and destination.countryId = V_countryId and destination.display  =7
where loc_eneighbor_region_id is not null;



INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId`,countryId,created_at )
select distinct destination.desId,'Tourico',test.tourico_region_world.destinationId5, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.loc_ecity_region_id and destination.countryId = V_countryId and destination.display  =7
where loc_ecity_region_id is not null;

 

INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Tourico',test.tourico_region_world.destinationId5, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.loc_emulti_city_region_id and destination.countryId = V_countryId and destination.display  =7
where loc_emulti_city_region_id is not null;


INSERT INTO hotel_test.`map_destination` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `regionType`, `expedia_regionId` ,countryId,created_at)
select distinct destination.desId,'Tourico',test.tourico_region_world.destinationId5, destination.desName,destination.RegionType,destination.RegionID,destination.countryId,now()
from test.tourico_region_world 
inner join hotel_test.destination on destination.desId = tourico_region_world.loc_emulti_region_region_id and destination.countryId = V_countryId and destination.display  =7
where loc_emulti_region_region_id is not null;

 
 
END;

