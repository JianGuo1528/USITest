CREATE PROCEDURE proc_destination_ScenicArea02(IN V_countryName VARCHAR(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		

SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;



update `hotel_test`.scenic_area set scenic_area.destination_id = null,scenic_area.destination_name = null  where scenic_area.countryId = V_countryId  and scenic_area.type != 'pnlAirport';
COMMIT;


 
	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or destination.city = concat(scenic_area.city,' (region)') or REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')   ) 
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Multi-Region (within a country)'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;


	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or destination.city = concat(scenic_area.city,' (and vicinity)') or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')  ) 
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Multi-City (Vicinity)'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;


	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')  )
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'City'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;

	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city  or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','') )
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Neighborhood'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;
 
	
update  hotel_test.scenic_area 
inner join hotel_test.destination on  scenic_area.destination_id = destination.desId and destination.display  =7
set scenic_area.destination_name = destination.desName
where scenic_area.countryId = V_countryId and scenic_area.destination_id is not null ;
	COMMIT;
	


	END;

