create procedure proc_destination_Destination_us_hotelbeds(IN V_countryName varchar(64))
  BEGIN

	DECLARE V_regionId int ;   
	DECLARE V_countryCode VARCHAR(64) ;   
	DECLARE V_countryId int ;   


	
	SELECT 'US',181 into V_countryCode,V_countryId;

       
  
 
 
	 -- hotelbeds_map_zone_world_new ======================================================
	 -- hotelbeds_map_zone_world_new ======================================================
	 -- hotelbeds_map_zone_world_new ======================================================
	 -- hotelbeds_map_zone_world_new ======================================================
update test.hotelbeds_map_zone_world_new 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null ,
loc_emulti_city_region_id = null ,loc_ecity_region_id = null,  loc_eneighbor_region_id = null, loc_emulti_region_region_id= null,ee_date = null 
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world_new 
 inner join (
		 select destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province
		from  test.hotelbeds_map_zone_world_new
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world_new.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_world_new.zoneName,' (region)')   or REPLACE (REPLACE(hotelbeds_map_zone_world_new.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and hotelbeds_map_zone_world_new.province = destination.Province_code
		and destination.RegionType = 'Multi-Region (within a country)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.zoneName = aa.zoneName and hotelbeds_map_zone_world_new.zoneCode = aa.zoneCode 
 and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.loc_emulti_region_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world_new 
 inner join (
		 select destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province
		from  test.hotelbeds_map_zone_world_new
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world_new.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_world_new.zoneName,' (and vicinity)')  or REPLACE (REPLACE(hotelbeds_map_zone_world_new.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and hotelbeds_map_zone_world_new.province = destination.Province_code
		and destination.RegionType = 'Multi-City (Vicinity)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.zoneName = aa.zoneName and hotelbeds_map_zone_world_new.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.loc_emulti_city_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world_new 
 inner join (
		 select destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province
		from  test.hotelbeds_map_zone_world_new
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world_new.zoneName = destination.city   or REPLACE (REPLACE(hotelbeds_map_zone_world_new.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and hotelbeds_map_zone_world_new.province = destination.Province_code
		and destination.RegionType = 'City'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.zoneName = aa.zoneName and hotelbeds_map_zone_world_new.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.loc_ecity_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world_new 
 inner join (
		 select destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province
		from  test.hotelbeds_map_zone_world_new
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_world_new.zoneName = destination.city or REPLACE (REPLACE(hotelbeds_map_zone_world_new.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and hotelbeds_map_zone_world_new.province = destination.Province_code
		and destination.RegionType = 'Neighborhood'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_world_new.city,zoneName,hotelbeds_map_zone_world_new.zoneCode,desId, hotelbeds_map_zone_world_new.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.zoneName = aa.zoneName and hotelbeds_map_zone_world_new.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.loc_eneighbor_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



--   -------------------------------------------

 update test.hotelbeds_map_zone_world_new 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_world_new  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or destination.city = concat(kk.city,' (region)')   or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and destination.RegionType = 'Multi-Region (within a country)'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.emulti_region_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_world_new 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_world_new  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or destination.city = concat(kk.city,' (and vicinity)') or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Multi-City (Vicinity)'
		group by destinationPId,city,desId,kk.province having count(1) = 1
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.emulti_city_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world_new 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_world_new  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'City'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.ecity_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_world_new 
 inner join (
 
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_world_new  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and ( kk.city = destination.city or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Neighborhood'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_world_new.destinationPId = aa.destinationPId and hotelbeds_map_zone_world_new.city = aa.city and hotelbeds_map_zone_world_new.province = aa.province
set hotelbeds_map_zone_world_new.eneighbor_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;

 


 
END;

