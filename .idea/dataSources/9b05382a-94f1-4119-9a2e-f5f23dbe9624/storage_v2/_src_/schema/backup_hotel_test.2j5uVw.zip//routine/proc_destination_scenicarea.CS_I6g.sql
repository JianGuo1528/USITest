create procedure proc_destination_ScenicArea(IN V_countryName varchar(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		

	SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

 
update test.pnlLocation set city = null ,area = null WHERE `洲` LIKE   CONCAT('%，',V_CountryName_zh,'%');
 COMMIT;

delete from hotel_test.scenic_area where countryId = V_countryId;
COMMIT;

insert into hotel_test.scenic_area (name,name_zh,name_short,name_full,type,destination_id,city,destination_name,destination_name_zh,countryId )
SELECT distinct null,null,null,`商圈`,'pnlZone',null,name_en,null,name_cn,V_countryId  FROM `test`.`zone`  where `国家` = V_CountryName_zh and  `商圈`is not null

union all 
SELECT distinct null,null,null,`景点`,'pnlDistrict',null,name_en,null,name_cn,V_countryId  FROM `test`.`zone`  where `国家` = V_CountryName_zh and  `景点`is not null

union all 
SELECT distinct null,null,null,`行政区`,'pnlLocation',null,null,city,`洲`,V_countryId  FROM  test.pnlLocation WHERE `洲` LIKE CONCAT('%，',V_CountryName_zh,'%');

COMMIT;

	
update `hotel_test`.scenic_area set name =  replace(SUBSTRING_INDEX(name_full,'(',-1),')',''),  name_zh = SUBSTRING_INDEX(name_full,'(',1)  where countryId = V_countryId;
COMMIT;  
 
	update hotel_test.destination aa
	inner join hotel_test.destination bb on aa.desName = bb.desName and aa.countryId = bb.countryId
	set aa.desName_zh = bb.desName_zh
	where aa.countryId = V_countryId and aa.display = 7 ;
	 
 COMMIT;


update `hotel_test`.scenic_area set scenic_area.destination_id = null,scenic_area.destination_name = null  where scenic_area.countryId = V_countryId  and scenic_area.type != 'pnlAirport';
COMMIT;


 
	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or destination.city = concat(scenic_area.city,' (region)') or REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')   ) 
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Multi-Region (within a country)'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;


	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or destination.city = concat(scenic_area.city,' (and vicinity)') or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')  ) 
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Multi-City (Vicinity)'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;


	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','')  )
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'City'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;

	update hotel_test.scenic_area
	inner join  (
	 
		select id,destination.desId  ,count(1)
		from hotel_test.scenic_area
		inner join hotel_test.destination on  (destination.city = scenic_area.city  or  REPLACE (REPLACE(destination.city,' ',''),'-','')   = REPLACE ( REPLACE(scenic_area.city,' ',''),'-','') )
		and scenic_area.countryId = destination.countryId and destination.display = 7 and destination.RegionType = 'Neighborhood'
		where scenic_area.countryId = V_countryId and scenic_area.destination_id is null  
		group by id,destination.desId having count(1) = 1
	 
	) aa on scenic_area.id = aa.id
	set hotel_test.scenic_area.destination_id = aa.desId
	where scenic_area.countryId = V_countryId and scenic_area.destination_id is null ;
 COMMIT;
 
	
update hotel_test.scenic_area 
inner join hotel_test.destination on  scenic_area.destination_id = destination.desId and destination.display  =7
set scenic_area.destination_name = destination.desName
where scenic_area.countryId = V_countryId and scenic_area.destination_id is not null ;
	COMMIT;
	
/*
 
update `test`.`pnlAirport` set pnlAirport.desId = null WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') ;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on SUBSTRING_INDEX(`Location served`,',',1)  = destination.city and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Multi-Region (within a country)'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;
	
	
update `test`.`pnlAirport` 
inner join hotel_test.destination on SUBSTRING_INDEX(`Location served`,',',1)  = destination.city and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Multi-City (Vicinity)'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on SUBSTRING_INDEX(`Location served`,',',1)  = destination.city and destination.countryId = V_countryId and display = 7 and destination.RegionType ='City'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on SUBSTRING_INDEX(`Location served`,',',1)  = destination.city and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Neighborhood'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

	*/
 
 /*
		insert into `hotel_test`.`scenic_area`
	(
	 `name`,
	 `name_zh`,
	 `name_short`,
	 `name_full`,
	 `type`,
	 `destination_id`,
	 `destination_name`,
	 countryId

 )
select  
pnlAirport.`Airport name`,
pnlAirport.`机场名称`,
pnlAirport.`IATA代码`,
(
	case 
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null and pnlAirport.`机场名称` =  pnlAirport.`Airport name` then pnlAirport.`Airport name`
  when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null and pnlAirport.`Airport name` like concat('%',pnlAirport.`机场名称`,'%') then pnlAirport.`Airport name`
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null then concat(pnlAirport.`机场名称`,'(',pnlAirport.`Airport name`,')')
	when pnlAirport.`机场名称` is null and pnlAirport.`Airport name` is not null then pnlAirport.`Airport name`
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is  null then pnlAirport.`机场名称`
	end
) aa ,
'pnlAirport',
destination.desId,
destination.desName,
V_countryId
from test.pnlAirport 
INNER JOIN hotel_test.destination ON destination.desId= pnlAirport.desId
where pnlAirport.desID is not null and  `国家和地区` LIKE  CONCAT('%',V_CountryName_zh,'%');
 
	*/
	END;

