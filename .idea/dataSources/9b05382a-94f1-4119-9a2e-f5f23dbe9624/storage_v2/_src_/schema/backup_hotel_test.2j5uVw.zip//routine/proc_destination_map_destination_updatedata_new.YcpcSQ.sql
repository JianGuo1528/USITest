create procedure proc_destination_Map_Destination_updateData_new()
  BEGIN

 	DECLARE V_countryCode VARCHAR(64) ;   
	DECLARE V_countryId int ;   



DECLARE done INT DEFAULT FALSE; -- 自定义控制游标循环变量,默认false  
  
DECLARE My_Cursor CURSOR FOR (		

SELECT countryCode , countryId FROM `test`.`hotelbeds_map_zone_world_new`
inner join `hotel_test`.`country` on hotelbeds_map_zone_world_new.isoCode = country.countryCode
WHERE `status` <> 'delete' group by isocode,countryId


); -- 定义游标并输入结果集  
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 绑定控制变量到游标,游标循环结束自动转true  
  
-- delete 	from hotel_test.`map_destination_hotelBeds` where map_destination_hotelBeds.created_at is not null;

OPEN My_Cursor; -- 打开游标  
  myLoop: LOOP -- 开始循环体,myLoop为自定义循环名,结束循环时用到  
    FETCH My_Cursor into V_countryCode,V_countryId; -- 将游标当前读取行的数据顺序赋予自定义变量12 
	
    IF done THEN -- 判断是否继续循环  
      LEAVE myLoop; -- 结束循环  
    END IF;  
		
		
			
						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world_new.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.loc_eneighbor_region_id and destination.countryId = V_countryId  and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  loc_eneighbor_region_id is not null and `status` <> 'delete';


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId`,countryId,created_at ,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world_new.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.loc_ecity_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  loc_ecity_region_id is not null and `status` <> 'delete';


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world_new.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.loc_emulti_city_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  loc_emulti_city_region_id is not null and `status` <> 'delete';


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,test.hotelbeds_map_zone_world_new.zoneCode,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.loc_emulti_region_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  loc_emulti_region_region_id is not null and `status` <> 'delete';


						 -- =======================

						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.eneighbor_region_id and destination.countryId = V_countryId  and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  eneighbor_region_id is not null and `status` <> 'delete';


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId`,countryId,created_at,flg )
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.ecity_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  ecity_region_id is not null and `status` <> 'delete'; 


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.emulti_city_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  emulti_city_region_id is not null and `status` <> 'delete';


						INSERT INTO hotel_test.`map_destination_hotelBeds` ( `destinationId`, `provider`, `destinationPId`, `regionNameLong`, `zoneCode`, `regionType`, `expedia_regionId` ,countryId,created_at,flg)
						select distinct destination.desId,'Hotelbeds',destinationPId, destination.desName,0,destination.RegionType,destination.RegionID,destination.countryId,now(),status
						from test.hotelbeds_map_zone_world_new
						inner join hotel_test.destination on destination.desId = hotelbeds_map_zone_world_new.emulti_region_region_id and destination.countryId = V_countryId and destination.display  in (1,4,5)
						WHERE `isoCode` = V_countryCode and  emulti_region_region_id is not null and `status` <> 'delete';
		
--  and `status` <> 'delete';
	 
								
		
		
		    COMMIT; -- 提交事务  
  END LOOP myLoop; -- 结束自定义循环体  
  CLOSE My_Cursor; -- 关闭游标  
 


 

 
 
END;

