create procedure proc_destination_Hotel(IN V_countryName varchar(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		 
	SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;



 update `hotel_test`.`hotel` 
 inner join hotel_test.map_hotel on hotel.hotelId = map_hotel.hotelId and hotel.provider = map_hotel.provider
 inner join test.`Hotels-Hotelbeds` on test.`Hotels-Hotelbeds`.hotelId = map_hotel.hotelPId  and test.`Hotels-Hotelbeds`.desId != `hotel_test`.`hotel`.desPid
 set hotel.desPid = test.`Hotels-Hotelbeds`.desId, hotel.zoneCode = test.`Hotels-Hotelbeds`.zoneCode
 WHERE `countryId` = V_countryId and  hotel.provider = 'hotelbeds' ;
  commit;

 update `hotel_test`.`hotel` set desid = null  where countryId = V_countryId   AND `provider` <> 'Innstant';
 commit;

 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider like concat('%',map_destination.provider,'%') and hotel.zoneCode = map_destination.zoneCode and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId = hotel.countryId and destination.RegionType = 'Multi-Region (within a country)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;

 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and hotel.zoneCode = map_destination.zoneCode and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId = hotel.countryId and destination.RegionType = 'Multi-City (Vicinity)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider  in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;
  
 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and hotel.zoneCode = map_destination.zoneCode and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId = hotel.countryId and destination.RegionType ='City'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
  commit;
   
 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and hotel.zoneCode = map_destination.zoneCode and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId = hotel.countryId and destination.RegionType ='Neighborhood'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider  in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;


 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and map_destination.countryId  =  hotel.countryId and  hotel_test.map_destination.zoneCode = 0
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId =  hotel.countryId and destination.RegionType = 'Multi-Region (within a country)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;

 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and map_destination.countryId  =  hotel.countryId  and  hotel_test.map_destination.zoneCode = 0
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId =  hotel.countryId and destination.RegionType = 'Multi-City (Vicinity)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;
  
 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and map_destination.countryId  =  hotel.countryId  and  hotel_test.map_destination.zoneCode = 0
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId =  hotel.countryId and destination.RegionType ='City'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
  commit;
   
 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider  like concat('%',map_destination.provider,'%')  and map_destination.countryId  =  hotel.countryId  and  hotel_test.map_destination.zoneCode = 0
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId =  hotel.countryId and destination.RegionType ='Neighborhood'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in( 'HotelBeds', 'HotelBeds, Innstant') and hotel.desId is null;
 commit;


update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider = map_destination.provider and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId = hotel.countryId and destination.RegionType = 'Multi-Region (within a country)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in ('Expedia','Priceline','Tourico')  and hotel.desId is null;
 commit;

update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider = map_destination.provider and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 
 and  destination.countryId = hotel.countryId and destination.RegionType = 'Multi-City (Vicinity)'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in ('Expedia','Priceline','Tourico')  and hotel.desId is null;
  commit;
   
 update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider = map_destination.provider and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId = hotel.countryId and destination.RegionType ='City'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in ('Expedia','Priceline','Tourico')  and hotel.desId is null;
  commit;
	
  update hotel_test.hotel 
 inner join hotel_test.map_destination on hotel.despid = map_destination.destinationPId and hotel.provider = map_destination.provider and map_destination.countryId  = hotel.countryId
 inner join hotel_test.destination on destination.desId =  map_destination.destinationId and destination.display = 7 and  destination.countryId = hotel.countryId and destination.RegionType ='Neighborhood'
 set hotel.desId = destination.desId
 where hotel.countryId = V_countryId  and hotel.provider in ('Expedia','Priceline','Tourico')  and hotel.desId is null;
 commit;
 

END;

