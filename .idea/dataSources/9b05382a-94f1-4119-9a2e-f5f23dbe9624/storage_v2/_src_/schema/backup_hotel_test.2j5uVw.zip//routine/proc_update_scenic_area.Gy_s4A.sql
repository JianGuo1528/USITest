CREATE PROCEDURE proc_update_scenic_area(IN scenic_area_countryId INT(3), IN destination_countryId INT(3),
                                         IN destination_display   INT(2))
  BEGIN
	UPDATE
		hotel_test.scenic_area,
		hotel_test.destination
	SET scenic_area.destination_id = destination.desId
	WHERE scenic_area.countryId = scenic_area_countryId
		AND destination.countryId = destination_countryId
		AND destination.display = destination_display
		AND destination.RegionType = 'Multi-Region (within a country)'
		AND fc_replaceStr(fc_replaceStrAbbr(destination.city)) = fc_replaceStr(fc_replaceStrAbbr(scenic_area.city))
		AND scenic_area.destination_id IS NULL;
		
	UPDATE
		hotel_test.scenic_area,
		hotel_test.destination
	SET scenic_area.destination_id = destination.desId
	WHERE scenic_area.countryId = scenic_area_countryId
		AND destination.countryId = destination_countryId
		AND destination.display = destination_display
		AND destination.RegionType = 'Multi-City (Vicinity)'
		AND fc_replaceStr(fc_replaceStrAbbr(destination.city)) = fc_replaceStr(fc_replaceStrAbbr(scenic_area.city))
		AND scenic_area.destination_id IS NULL;
		
	UPDATE
		hotel_test.scenic_area,
		hotel_test.destination
	SET scenic_area.destination_id = destination.desId
	WHERE scenic_area.countryId = scenic_area_countryId
		AND destination.countryId = destination_countryId
		AND destination.display = destination_display
		AND destination.RegionType = 'City'
		AND fc_replaceStr(fc_replaceStrAbbr(destination.city)) = fc_replaceStr(fc_replaceStrAbbr(scenic_area.city))
		AND scenic_area.destination_id IS NULL;

	UPDATE
		hotel_test.scenic_area,
		hotel_test.destination
	SET scenic_area.destination_id = destination.desId
	WHERE scenic_area.countryId = scenic_area_countryId
		AND destination.countryId = destination_countryId
		AND destination.display = destination_display
		AND destination.RegionType = 'Neighborhood'
		AND fc_replaceStr(fc_replaceStrAbbr(destination.city)) = fc_replaceStr(fc_replaceStrAbbr(scenic_area.city))
		AND scenic_area.destination_id IS NULL;
END;

