create procedure proc_destination_Destination_us(IN V_countryName varchar(64))
  BEGIN

	DECLARE V_regionId int ;   
	DECLARE V_countryCode VARCHAR(64) ;   
	DECLARE V_countryId int ;   


	
	SELECT 'US',181 into V_countryCode,V_countryId;

 
 
UPDATE test.bonotel_cityList 
SET 
bonotel_cityList.eneighbor_region_id = NULL ,
bonotel_cityList.emulti_city_region_id = NULL ,
bonotel_cityList.ecity_region_id = NULL,
bonotel_cityList.emulti_region_region_id = NULL,
bonotel_cityList.flag = NULL,e_date = null 
where bonotel_cityList.`Country Code` = V_countryCode;
 
 
update test.bonotel_cityList 
inner join  hotel_test.destination on bonotel_cityList.`State Code` = destination.Province_code and RegionType = 'Multi-Region (within a country)' and destination.display in (1,4,5)
and ( concat(bonotel_cityList.`City Name`,' (within a country)') = destination.city or bonotel_cityList.`City Name` = destination.city  )
set bonotel_cityList.emulti_city_region_id = destination.desId , e_date = now()
where bonotel_cityList.`Country Code` = V_countryCode;
 
 
update test.bonotel_cityList 
inner join  hotel_test.destination on bonotel_cityList.`State Code` = destination.Province_code and RegionType = 'Multi-City (Vicinity)' and destination.display in (1,4,5)
and ( concat(bonotel_cityList.`City Name`,' (and vicinity)') = destination.city or bonotel_cityList.`City Name` = destination.city  )
set bonotel_cityList.emulti_city_region_id = destination.desId , e_date = now()
where bonotel_cityList.`Country Code` =V_countryCode;


update test.bonotel_cityList 
inner join  hotel_test.destination on bonotel_cityList.`State Code` = destination.Province_code and RegionType = 'City' and destination.display in (1,4,5)
and  bonotel_cityList.`City Name` = destination.city  
set bonotel_cityList.ecity_region_id = destination.desId , e_date = now()
where bonotel_cityList.`Country Code` = V_countryCode;

 
update test.bonotel_cityList 
inner join  hotel_test.destination on bonotel_cityList.`State Code` = destination.Province_code and RegionType = 'Neighborhood' and destination.display in (1,4,5)
and  bonotel_cityList.`City Name` = destination.city  
set bonotel_cityList.eneighbor_region_id = destination.desId , e_date = now()
where bonotel_cityList.`Country Code` = V_countryCode;

 
 

 -- _priceline
update test.city_priceline 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null 
where city_priceline.countryId = V_countryId ;


update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display in (1,4,5)
				and (city_priceline.city = destination.city or destination.city = concat(city_priceline.city,' (region)') )
				and city_priceline.state_code = destination.Province_code and destination.RegionType = 'Multi-Region (within a country)'
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.emulti_region_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;
 
 
 
 update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display in (1,4,5)
				and (city_priceline.city = destination.city or destination.city = concat(city_priceline.city,' (and vicinity)') )
				and city_priceline.state_code = destination.Province_code and destination.RegionType = 'Multi-City (Vicinity)'
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.emulti_city_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;
 
update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display in (1,4,5)
				and city_priceline.city = destination.city 
				and city_priceline.state_code = destination.Province_code and destination.RegionType = 'City' 
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.ecity_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;



update test.city_priceline 
inner join (
				select cityid_ppn,destination.desId,count(1) from test.city_priceline 
				inner join hotel_test.destination on  destination.countryId = city_priceline.countryId and display  in (1,4,5)
				and city_priceline.city = destination.city 
				and city_priceline.state_code = destination.Province_code and destination.RegionType = 'Neighborhood' 
				where  city_priceline.countryId = V_countryId 
				group by cityid_ppn,destination.desId HAVING count(1) = 1
) aa  on city_priceline.cityid_ppn = aa.cityid_ppn
set city_priceline.eneighbor_region_id = aa.desId,e_date = now()
where  city_priceline.countryId = V_countryId ;



 




-- tourico_region ======================================================
-- tourico_region ======================================================
-- tourico_region ======================================================
update test.tourico_region_world 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null ,
 loc_emulti_city_region_id = null ,loc_ecity_region_id = null,  loc_eneighbor_region_id = null, loc_emulti_region_region_id= null ,ee_date = null 
WHERE `country` = V_countryCode;


 -- ====================================================== tourico city
update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,StateShort,desId,count(1)  from (
			select city_id,destinationCode,city_name,StateShort from test.tourico_region_world where `country` = V_countryCode group by city_id,destinationCode,city_name,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId 
		and (tourico_region_world.city_name = destination.city or destination.city = concat(tourico_region_world.city_name,' (region)') )
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Multi-Region (within a country)'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.emulti_region_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;


update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,StateShort,desId,count(1)  from (
			select city_id,destinationCode,city_name,StateShort from test.tourico_region_world where `country` = V_countryCode group by city_id,destinationCode,city_name,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.city_name = destination.city or destination.city = concat(tourico_region_world.city_name,' (and vicinity)') )
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Multi-City (Vicinity)'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.emulti_city_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;



update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name,StateShort from test.tourico_region_world where `country` = V_countryCode group by city_id,destinationCode,city_name,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.city_name = destination.city
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'City'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.ecity_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;
 

update test.tourico_region_world 
inner join  (

		select city_id,destinationCode,city_name,desId,count(1)  from (
			select city_id,destinationCode,city_name,StateShort from test.tourico_region_world where `country` = V_countryCode group by city_id,destinationCode,city_name,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.city_name = destination.city
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Neighborhood'
		group by city_id,destinationCode,city_name,desId having count(1) = 1

) aa on tourico_region_world.city_id = aa.city_id

set tourico_region_world.eneighbor_region_id = aa.desId,e_date = now()
WHERE `country` = V_countryName;

 -- ====================================================== tourico loc_

update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,StateShort,desId,count(1)  from (
			select destinationId5,destinationCode,location,StateShort from test.tourico_region_world where `country` = V_countryCode group by destinationId5,destinationCode,location,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.location = destination.city or destination.city = concat(tourico_region_world.location,' (region)') )
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Multi-Region (within a country)' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1


) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_emulti_region_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;


update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,StateShort,desId,count(1)  from (
			select destinationId5,destinationCode,location,StateShort from test.tourico_region_world where `country` = V_countryCode group by destinationId5,destinationCode,location,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (tourico_region_world.location = destination.city or destination.city = concat(tourico_region_world.location,' (and vicinity)') )
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Multi-City (Vicinity)' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_emulti_city_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;



update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,StateShort,desId,count(1)  from (
			select destinationId5,destinationCode,location,StateShort from test.tourico_region_world where `country` = V_countryCode group by destinationId5,destinationCode,location,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.location = destination.city
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'City' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_ecity_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;
 

update test.tourico_region_world 
inner join  (

		select destinationId5,destinationCode,location,StateShort,desId,count(1)  from (
			select destinationId5,destinationCode,location,StateShort from test.tourico_region_world where `country` = V_countryCode group by destinationId5,destinationCode,location,StateShort
		) tourico_region_world
		inner join hotel_test.destination on destination.countryId = V_countryId
		and tourico_region_world.location = destination.city
		and tourico_region_world.StateShort = destination.Province_code
		and destination.RegionType = 'Neighborhood' and destinationId5 is not null and location is not null
		group by destinationId5,destinationCode,location,desId having count(1) = 1

) aa on tourico_region_world.destinationId5 = aa.destinationId5

set tourico_region_world.loc_eneighbor_region_id = aa.desId,ee_date = now()
WHERE `country` = V_countryName;
 
 
 
  
 
 
	 -- hotelbeds_map_zone_us ======================================================
	 -- hotelbeds_map_zone_us ======================================================
	 -- hotelbeds_map_zone_us ======================================================
	 -- hotelbeds_map_zone_us ======================================================
update test.hotelbeds_map_zone_us 
set emulti_city_region_id = null ,ecity_region_id = null,  eneighbor_region_id = null, emulti_region_region_id= null,  flag = null ,e_date = null ,
loc_emulti_city_region_id = null ,loc_ecity_region_id = null,  loc_eneighbor_region_id = null, loc_emulti_region_region_id= null,ee_date = null 
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_us 
 inner join (
		 select destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province
		from  test.hotelbeds_map_zone_us
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_us.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_us.zoneName,' (region)')   or REPLACE (REPLACE(hotelbeds_map_zone_us.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and hotelbeds_map_zone_us.province = destination.Province_code
		and destination.RegionType = 'Multi-Region (within a country)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.zoneName = aa.zoneName and hotelbeds_map_zone_us.zoneCode = aa.zoneCode 
 and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.loc_emulti_region_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_us 
 inner join (
		 select destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province
		from  test.hotelbeds_map_zone_us
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_us.zoneName = destination.city or destination.city = concat(hotelbeds_map_zone_us.zoneName,' (and vicinity)')  or REPLACE (REPLACE(hotelbeds_map_zone_us.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and hotelbeds_map_zone_us.province = destination.Province_code
		and destination.RegionType = 'Multi-City (Vicinity)'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.zoneName = aa.zoneName and hotelbeds_map_zone_us.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.loc_emulti_city_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_us 
 inner join (
		 select destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province
		from  test.hotelbeds_map_zone_us
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_us.zoneName = destination.city   or REPLACE (REPLACE(hotelbeds_map_zone_us.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and hotelbeds_map_zone_us.province = destination.Province_code
		and destination.RegionType = 'City'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.zoneName = aa.zoneName and hotelbeds_map_zone_us.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.loc_ecity_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_us 
 inner join (
		 select destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province
		from  test.hotelbeds_map_zone_us
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (hotelbeds_map_zone_us.zoneName = destination.city or REPLACE (REPLACE(hotelbeds_map_zone_us.zoneName,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')  )
		and hotelbeds_map_zone_us.province = destination.Province_code
		and destination.RegionType = 'Neighborhood'
		WHERE `isoCode` = V_countryCode and zoneName is not null
		group by destinationPId,hotelbeds_map_zone_us.city,zoneName,hotelbeds_map_zone_us.zoneCode,desId, hotelbeds_map_zone_us.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.zoneName = aa.zoneName and hotelbeds_map_zone_us.zoneCode = aa.zoneCode
  and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.loc_eneighbor_region_id = aa.desId,ee_date = now()
WHERE `isoCode` = V_countryCode;



--   -------------------------------------------

 update test.hotelbeds_map_zone_us 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_us  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or destination.city = concat(kk.city,' (region)')   or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','')   )
		and destination.RegionType = 'Multi-Region (within a country)'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.emulti_region_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;


 update test.hotelbeds_map_zone_us 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_us  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or destination.city = concat(kk.city,' (and vicinity)') or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Multi-City (Vicinity)'
		group by destinationPId,city,desId,kk.province having count(1) = 1
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.emulti_city_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_us 
 inner join (
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_us  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and (kk.city = destination.city or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'City'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.ecity_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;



 update test.hotelbeds_map_zone_us 
 inner join (
 
		select destinationPId,kk.city,desId,kk.province
		from  (
				select  destinationPId,city,province 
				from  test.hotelbeds_map_zone_us  
				WHERE `isoCode` = V_countryCode and city is not null 
				group by destinationPId,city,province
		) kk
		inner join hotel_test.destination on destination.countryId = V_countryId
		and ( kk.city = destination.city or REPLACE (REPLACE(kk.city,' ',''),'-','')  = REPLACE ( REPLACE(destination.city,' ',''),'-','') )
		and destination.RegionType = 'Neighborhood'
		group by destinationPId,city,desId,kk.province having count(1) = 1
		 
 )aa on  hotelbeds_map_zone_us.destinationPId = aa.destinationPId and hotelbeds_map_zone_us.city = aa.city and hotelbeds_map_zone_us.province = aa.province
set hotelbeds_map_zone_us.eneighbor_region_id = aa.desId,e_date = now()
WHERE `isoCode` = V_countryCode;

 


 
END;

