CREATE PROCEDURE proc_destination_ScenicArea01(IN V_countryName VARCHAR(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		

SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

 
update test.pnlLocation set city = null ,area = null WHERE `洲` LIKE   CONCAT('%，',V_CountryName_zh,'%');
 COMMIT;

delete from hotel_test.scenic_area where countryId = V_countryId;
COMMIT;

insert into hotel_test.scenic_area (name,name_zh,name_short,name_full,type,destination_id,city,destination_name,destination_name_zh,countryId )
SELECT distinct null,null,null,`商圈`,'pnlZone',null,name_en,null,name_cn,V_countryId  FROM `test`.`zone`  where `国家` = V_CountryName_zh and  `商圈`is not null

union all 
SELECT distinct null,null,null,`景点`,'pnlDistrict',null,name_en,null,name_cn,V_countryId  FROM `test`.`zone`  where `国家` = V_CountryName_zh and  `景点`is not null

union all 
SELECT distinct null,null,null,`行政区`,'pnlLocation',null,null,city,`洲`,V_countryId  FROM  test.pnlLocation WHERE `洲` LIKE CONCAT('%，',V_CountryName_zh,'%');

COMMIT;


update `hotel_test`.scenic_area set name =  replace(SUBSTRING_INDEX(name_full,'(',-1),')',''),  name_zh = SUBSTRING_INDEX(name_full,'(',1)  where countryId = V_countryId;
COMMIT;  
 
	update hotel_test.destination aa
	inner join hotel_test.destination bb on aa.desName = bb.desName and aa.countryId = bb.countryId
	set aa.desName_zh = bb.desName_zh
	where aa.countryId = V_countryId and aa.display = 7 ;
	 
 COMMIT;



	END;

