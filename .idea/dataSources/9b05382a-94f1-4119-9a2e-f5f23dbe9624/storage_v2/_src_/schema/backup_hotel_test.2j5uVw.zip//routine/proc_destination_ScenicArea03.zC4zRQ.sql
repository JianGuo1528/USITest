CREATE PROCEDURE proc_destination_ScenicArea03(IN V_countryName VARCHAR(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		

SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

 
 
update `test`.`pnlAirport` set pnlAirport.desId = null WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') ;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on ( SUBSTRING_INDEX(`Location served`,',',1)  = destination.city  or `Location served` = destination.desName )  and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Multi-Region (within a country)'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;
	
	
update `test`.`pnlAirport` 
inner join hotel_test.destination on ( SUBSTRING_INDEX(`Location served`,',',1)  = destination.city  or `Location served` = destination.desName ) and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Multi-City (Vicinity)'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on ( SUBSTRING_INDEX(`Location served`,',',1)  = destination.city  or `Location served` = destination.desName ) and destination.countryId = V_countryId and display = 7 and destination.RegionType ='City'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

update `test`.`pnlAirport` 
inner join hotel_test.destination on ( SUBSTRING_INDEX(`Location served`,',',1)  = destination.city  or `Location served` = destination.desName ) and destination.countryId = V_countryId and display = 7 and destination.RegionType ='Neighborhood'
set pnlAirport.desId = destination.desId
WHERE `国家和地区` LIKE CONCAT('%', V_CountryName_zh ,'%') and pnlAirport.desId is null;
COMMIT;

	END;

