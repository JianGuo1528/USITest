CREATE PROCEDURE proc_update_addr_hotelbeds(IN hotelbeds_isoCode   VARCHAR(8), IN destination_countryId INT(3),
                                            IN destination_display INT(2), IN destination_regionType VARCHAR(32),
                                            IN zoneName_name       INT(1))
  BEGIN
	IF zoneName_name = 1 THEN
		IF destination_regionType = 'Multi-Region (within a country)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.emulti_region_region_id = destination.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.zoneName, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Multi-Region (within a country)'
			AND hotelbeds_map_zone_world.emulti_region_region_id IS NULL;
			
		ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.emulti_city_region_id = destination.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.zoneName, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Multi-City (Vicinity)'
			AND hotelbeds_map_zone_world.emulti_city_region_id IS NULL;
		
		ELSEIF destination_regionType = 'City' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.ecity_region_id = destination.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.zoneName, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'City'
			AND hotelbeds_map_zone_world.ecity_region_id IS NULL;
		
		ELSE
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.eneighbor_region_id = destination.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.zoneName, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Neighborhood'
			AND hotelbeds_map_zone_world.eneighbor_region_id IS NULL;
		
		END IF;
		
	ELSE
		IF destination_regionType = 'Multi-Region (within a country)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.emulti_region_region_id = destination.desId
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.`name`, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Multi-Region (within a country)'
			AND hotelbeds_map_zone_world.emulti_region_region_id IS NULL
			AND hotelbeds_map_zone_world.flag IS NULL;
			
		ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.emulti_city_region_id = destination.desId
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.`name`, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Multi-City (Vicinity)'
			AND hotelbeds_map_zone_world.emulti_city_region_id IS NULL
			AND hotelbeds_map_zone_world.flag IS NULL;
		
		ELSEIF destination_regionType = 'City' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.ecity_region_id = destination.desId
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.`name`, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'City'
			AND hotelbeds_map_zone_world.ecity_region_id IS NULL
			AND hotelbeds_map_zone_world.flag IS NULL;
		
		ELSE
			UPDATE
				test.hotelbeds_map_zone_world,
				hotel_test.destination
			SET hotelbeds_map_zone_world.eneighbor_region_id = destination.desId
			WHERE isoCode = hotelbeds_isoCode
			AND e_date IS NULL
			AND countryId = destination_countryId 
			AND display = destination_display
			AND fc_replaceStr(desName) LIKE CONCAT(fc_replaceStr(REPLACE(hotelbeds_map_zone_world.`name`, 'St', 'Saint')), ',%')
			AND destination.RegionType = 'Neighborhood'
			AND hotelbeds_map_zone_world.eneighbor_region_id IS NULL
			AND hotelbeds_map_zone_world.flag IS NULL;
		END IF;
	END IF;
END;

