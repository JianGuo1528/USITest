create procedure proc_destination_Destination_01(IN V_countryName varchar(64))
  BEGIN

	DECLARE V_regionId int ;   
	DECLARE V_countryCode VARCHAR (64) CHARACTER SET utf8;   
	DECLARE V_countryId int ;   

	
	 
	SELECT countryCode,countryId into V_countryCode,V_countryId  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

  SELECT regionId into V_regionId FROM `test`.`expedia_region_world` WHERE regionType = 'Country'  and regionName = V_countryName limit 1; 

	
	delete from `hotel_test`.`destination` where countryId = V_countryId and display = 7;

  INSERT INTO `hotel_test`.`destination`
	(
		 `regionId`,  `desName`, `display`,  `countryId`, 	`state`, `city`,  `Path`,  `Path_Name`,  
		 `RegionType`, `SubClass`,  `Parent_RegionID`, `Parent_RegionType`,  `Parent_RegionName`,  `Parent_RegionNameLong`,  `Province_code`
	)
  SELECT 
    u.regionId ,u.regionNamelong AS desName  ,7 AS display  ,V_countryId countryId  ,u.Province AS state ,u.regionName AS city, 	`Path`, `Path_Name`,
		`RegionType`, `SubClass`, `Parent_RegionID`, `Parent_RegionType`, `Parent_RegionName`, `Parent_RegionNameLong`, `Province_code`   
  FROM test.`expedia_region_world` u 
  WHERE  `Path` LIKE concat('%>',V_regionId,'>%');

 
END;

