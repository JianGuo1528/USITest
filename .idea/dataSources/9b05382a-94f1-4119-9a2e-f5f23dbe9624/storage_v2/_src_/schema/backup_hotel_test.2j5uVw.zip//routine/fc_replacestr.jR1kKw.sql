create function fc_replaceStr(str varchar(1000))
  returns varchar(1000)
  BEGIN

DECLARE sstr VARCHAR(1000);
	SELECT  REPLACE(REPLACE(REPLACE(REPLACE(str, '-', ''), '.', ''), '\'' ,''), ' ', '') INTO sstr;
	RETURN sstr;
END;

