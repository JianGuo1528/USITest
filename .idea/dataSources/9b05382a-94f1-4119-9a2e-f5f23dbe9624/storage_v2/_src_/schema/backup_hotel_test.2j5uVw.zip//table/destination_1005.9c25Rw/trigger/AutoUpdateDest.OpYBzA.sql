create trigger AutoUpdateDest
  before UPDATE
  on destination_1005
  for each row
  BEGIN   
set new.updated_at = NOW();
END;

