CREATE TRIGGER AutoUpdateDest
  BEFORE UPDATE
  ON destination_1005
  FOR EACH ROW
  BEGIN   
set new.updated_at = NOW();
END;

