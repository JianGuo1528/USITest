CREATE PROCEDURE proc_destination_ScenicArea04(IN V_countryName VARCHAR(64))
  BEGIN


	DECLARE V_countryCode VARCHAR(64) ;  
	DECLARE V_CountryName_zh VARCHAR(64) CHARACTER SET utf8;
	DECLARE V_countryId int ;   
	
		

SELECT countryCode,countryId,CountryName_zh into V_countryCode,V_countryId,V_CountryName_zh  FROM `hotel_test`.`country` WHERE `countryName` =  V_countryName LIMIT 1;

  
		insert into `hotel_test`.`scenic_area`
	(
	 `name`,
	 `name_zh`,
	 `name_short`,
	 `name_full`,
	 `type`,
	 `destination_id`,
	 `destination_name`,
	 countryId

 )
select  
pnlAirport.`Airport name`,
pnlAirport.`机场名称`,
pnlAirport.`IATA代码`,
(
	case 
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null and pnlAirport.`机场名称` =  pnlAirport.`Airport name` then pnlAirport.`Airport name`
  when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null and pnlAirport.`Airport name` like concat('%',pnlAirport.`机场名称`,'%') then pnlAirport.`Airport name`
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is not null then concat(pnlAirport.`机场名称`,'(',pnlAirport.`Airport name`,')')
	when pnlAirport.`机场名称` is null and pnlAirport.`Airport name` is not null then pnlAirport.`Airport name`
	when pnlAirport.`机场名称` is not null and pnlAirport.`Airport name` is  null then pnlAirport.`机场名称`
	end
) aa ,
'pnlAirport',
destination.desId,
destination.desName,
V_countryId
from test.pnlAirport 
INNER JOIN hotel_test.destination ON destination.desId= pnlAirport.desId
where pnlAirport.desID is not null and  `国家和地区` LIKE  CONCAT('%',V_CountryName_zh,'%');
 
	
	END;

