create procedure proc_update_addr_tourico(IN tourico_country     varchar(32), IN destination_countryId int(3),
                                          IN destination_display int(2), IN destination_regionType varchar(32))
  BEGIN
 	IF destination_regionType = 'Multi-Region (within a country)' THEN
  		UPDATE
  			test.tourico_region_world,
  			(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.emulti_region_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(tourico_region_world.city_name), ',%')
  		AND tourico_region_world.emulti_region_region_id IS NULL;
			
			UPDATE
  			test.tourico_region_world,
  			(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.loc_emulti_region_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND ee_date IS NULL
  		AND fc_replaceStr(tourico_region_world.location) LIKE CONCAT(fc_replaceStr(t.city), '%')
  		AND tourico_region_world.loc_emulti_region_region_id IS NULL;
  		
  	ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
  		UPDATE
  			test.tourico_region_world,
  			(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.emulti_city_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(tourico_region_world.city_name), ',%')
  		AND tourico_region_world.emulti_city_region_id IS NULL;
			
			UPDATE
  			test.tourico_region_world,
				(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.loc_emulti_city_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND ee_date IS NULL
  		AND fc_replaceStr(tourico_region_world.location) LIKE CONCAT(fc_replaceStr(t.city), '%')
  		AND tourico_region_world.loc_emulti_city_region_id IS NULL;
  		
  	ELSEIF destination_regionType = 'City' THEN
  		UPDATE
  			test.tourico_region_world,
				(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.ecity_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(tourico_region_world.city_name), ',%')
  		AND tourico_region_world.ecity_region_id IS NULL;
			
			UPDATE
  			test.tourico_region_world,
  			(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.loc_ecity_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND ee_date IS NULL
  		AND fc_replaceStr(tourico_region_world.location) LIKE CONCAT(fc_replaceStr(t.city), '%')
  		AND tourico_region_world.loc_ecity_region_id IS NULL;
  	
  	ELSE
  		UPDATE
  			test.tourico_region_world,
  			(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.eneighbor_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND e_date IS NULL
  		AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(tourico_region_world.city_name), ',%')
  		AND tourico_region_world.eneighbor_region_id IS NULL;
			
			UPDATE
  			test.tourico_region_world,
				(
				SELECT
					destination.desId,
					destination.desName,
					destination.city
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
  		SET tourico_region_world.loc_eneighbor_region_id = t.desId, tourico_region_world.flag = 'JIM'
  		WHERE country = tourico_country 
  		AND ee_date IS NULL
  		AND fc_replaceStr(tourico_region_world.location) LIKE CONCAT(fc_replaceStr(t.city), '%')
  		AND tourico_region_world.loc_eneighbor_region_id IS NULL;
 	
  	END IF;

END;

