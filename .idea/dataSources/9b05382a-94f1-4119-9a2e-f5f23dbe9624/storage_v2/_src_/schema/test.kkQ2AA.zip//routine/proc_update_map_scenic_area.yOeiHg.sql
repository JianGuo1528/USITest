create procedure proc_update_map_scenic_area()
  BEGIN
	DECLARE sa_id VARCHAR(16);
	DECLARE sa_name VARCHAR(32);
	DECLARE sa_type VARCHAR(64);
	DECLARE sa_countryId VARCHAR(16);
	DECLARE d_path VARCHAR(128);
	DECLARE len INT(2);
	-- 遍历数据结束标志
  DECLARE done INT DEFAULT FALSE;

	DECLARE cur CURSOR FOR 
	SELECT 
		scenic_area.id,
		scenic_area.`name`,	
		scenic_area.type,
		scenic_area.countryId,
		destination.path
	FROM 
		hotel_test.scenic_area,
		hotel_test.destination
	WHERE scenic_area.type <> 'pnlAirport'
	AND scenic_area.type <> 'pnlUniversity'
	AND scenic_area.type <> 'pnlHighSchool'
	AND destination_id IS NOT NULL
	AND destination_id = desId;
	
  -- 将结束标志绑定到游标
  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;
	
	-- 打开游标
  OPEN cur;
	read_loop: LOOP
    -- 提取游标里的数据；
		FETCH cur INTO sa_id, sa_name, sa_type, sa_countryId, d_path;
		
    -- 声明结束的时候
    IF done THEN
      LEAVE read_loop;
    END IF;
		
    -- 这里做你想做的循环的事件
		SELECT LENGTH(d_path) - LENGTH(REPLACE(d_path,'>','')) + 1 INTO len;
		
		WHILE len >= 2 DO
			-- id	scenic_area_id	destination_id	name	type	countryId
			INSERT INTO 
				hotel_test.map_scenic_area_0521(scenic_area_id, name, type, countryId, destination_id, regionType)
			SELECT 
				sa_id, sa_name, sa_type, sa_countryId, destination.desId, destination. regionType 
			FROM hotel_test.destination WHERE destination.path = SUBSTRING_INDEX(d_path,'>',len);
			
			SET len = len - 1;
			
			COMMIT;
		END WHILE;
  END LOOP;
  -- 关闭游标
	CLOSE cur;
	
END;

