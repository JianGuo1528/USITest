create function alphanum(str varchar(200), delimiters varchar(10), type char)
  returns varchar(200)
  BEGIN

 
  -- -----------------------------------------------------------
-- usage：select get_char("我wo是15国de3国花duo", ",", 'n');
-- -------------------------------------------------------------
-- 将字符串中的字符(中文、英文、数字)全部提出，并以分隔符分隔
-- @param str varchar(200) 输入字符串
-- @param delimiters varchar(20) 分隔符
-- @param type char(1) 提取的字符类型(c-中文, e-英文, n-数字)
-- @return varchar(200) 返回的字符串
-- -----------------------------------------------------------
declare i tinyint unsigned default 0;
declare len tinyint unsigned;
declare separators varchar(10) default "";
declare next_char char(1)  charset utf8 default null;
declare result_char varchar(200) charset utf8 default "";
declare regexp_rule varchar(50) charset utf8 default "";

set len=char_length(str);

if type='c' then
    set regexp_rule="[^ -~]";
elseif type='e' then
    set regexp_rule="[a-zA-Z]";
elseif type='n' then
    set regexp_rule="[0-9]";
else 
    return "";
end if;

while i<=len do
    set next_char=substring(str, i, 1);
    if next_char regexp regexp_rule then
        set result_char=concat_ws(separators, result_char, next_char);
        if substring(str, i+1, 1) regexp regexp_rule then
            set separators="";
        else
            set separators=delimiters;
        end if;
    end if;
    set i=i+1;
end while;

RETURN result_char;
END;

