create function getChildList(rootId int)
  returns varchar(1000)
  BEGIN
      DECLARE sChildList VARCHAR(1000);
      DECLARE sChildTemp VARCHAR(1000);
      SET sChildTemp =CAST(rootId AS CHAR);
      WHILE sChildTemp IS NOT NULL DO
        IF (sChildList IS NOT NULL) THEN
          SET sChildList = CONCAT(sChildList,',',sChildTemp);
    ELSE
      SET sChildList = CONCAT(sChildTemp);
    END IF;
        SELECT GROUP_CONCAT(RegionID) INTO sChildTemp FROM expedia_region_w WHERE FIND_IN_SET(Parent_RegionID,sChildTemp)>0;
      END WHILE;
      RETURN sChildList;
	 
 
    END;

