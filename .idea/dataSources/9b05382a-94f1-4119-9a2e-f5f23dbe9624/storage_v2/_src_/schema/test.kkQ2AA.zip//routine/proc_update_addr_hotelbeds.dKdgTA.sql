create procedure proc_update_addr_hotelbeds(IN hotelbeds_isoCode   varchar(8), IN destination_countryId int(3),
                                            IN destination_display int(2), IN destination_regionType varchar(32))
  BEGIN
		IF destination_regionType = 'Multi-Region (within a country)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.loc_emulti_region_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.zoneName), ',%')
			AND hotelbeds_map_zone_world.loc_emulti_region_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.emulti_region_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.name), ',%')
			AND hotelbeds_map_zone_world.emulti_region_region_id IS NULL;

		ELSEIF destination_regionType = 'Multi-City (Vicinity)' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.loc_emulti_city_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.zoneName), ',%')
			AND hotelbeds_map_zone_world.loc_emulti_city_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.emulti_city_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.name), ',%')
			AND hotelbeds_map_zone_world.emulti_city_region_id IS NULL;
		
		ELSEIF destination_regionType = 'City' THEN
			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.loc_ecity_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.zoneName), ',%')
			AND hotelbeds_map_zone_world.loc_ecity_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.ecity_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.name), ',%')
			AND hotelbeds_map_zone_world.ecity_region_id IS NULL;
		
		ELSE
			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.loc_eneighbor_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.zoneName), ',%')
			AND hotelbeds_map_zone_world.loc_eneighbor_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display = destination_display
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world.eneighbor_region_id = t.desId, hotelbeds_map_zone_world.flag = 'JIM'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world.name), ',%')
			AND hotelbeds_map_zone_world.eneighbor_region_id IS NULL;
	END IF;
END;

