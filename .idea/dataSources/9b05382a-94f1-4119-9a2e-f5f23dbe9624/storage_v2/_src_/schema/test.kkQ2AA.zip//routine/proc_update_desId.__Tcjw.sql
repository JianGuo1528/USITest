CREATE PROCEDURE proc_update_desId(IN flag                      VARCHAR(64), IN hotelbeds_map_zone_world_id INT,
                                   IN city_priceline_cityid_ppn INT, IN tourico_region_world_id INT, IN desId INT)
  BEGIN

if  hotelbeds_map_zone_world_id is not null then

UPDATE 
	`test`.hotelbeds_map_zone_world,
	`hotel_test`.destination
SET hotelbeds_map_zone_world.flag = flag,
		hotelbeds_map_zone_world.emulti_city_region_id = (
			CASE 
				WHEN destination.RegionType = 'Multi-City (Vicinity)' THEN destination.desId 
				ELSE hotelbeds_map_zone_world.emulti_city_region_id
			END
		),
		hotelbeds_map_zone_world.ecity_region_id = (
			CASE 
				WHEN destination.RegionType = 'City' THEN destination.desId
				ELSE hotelbeds_map_zone_world.ecity_region_id
			END
			),
		hotelbeds_map_zone_world.eneighbor_region_id = (
			CASE 
				WHEN destination.RegionType = 'Neighborhood' THEN destination.desId
				ELSE hotelbeds_map_zone_world.eneighbor_region_id
			END
			)
WHERE hotelbeds_map_zone_world.id = hotelbeds_map_zone_world_id
		AND destination.desId = desId;

end if;

if  city_priceline_cityid_ppn is not null then
UPDATE 
	`test`.city_priceline,
	`hotel_test`.destination
SET city_priceline.flag = flag,
		city_priceline.emulti_city_region_id = (
			CASE 
				WHEN destination.RegionType = 'Multi-City (Vicinity)' THEN destination.desId 
				ELSE city_priceline.emulti_city_region_id
			END
		),
		city_priceline.ecity_region_id = (
			CASE 
				WHEN destination.RegionType = 'City' THEN destination.desId
				ELSE city_priceline.ecity_region_id
			END
			),
		city_priceline.eneighbor_region_id = (
			CASE 
				WHEN destination.RegionType = 'Neighborhood' THEN destination.desId
				ELSE city_priceline.eneighbor_region_id
			END
			)
WHERE city_priceline.cityid_ppn = city_priceline_cityid_ppn
		AND destination.desId = desId;
		
end if;

if  tourico_region_world_id is not null then

UPDATE 
	`test`.tourico_region_world,
	`hotel_test`.destination
SET tourico_region_world.flag = flag,
		tourico_region_world.emulti_city_region_id = (
			CASE 
				WHEN destination.RegionType = 'Multi-City (Vicinity)' THEN destination.desId 
				ELSE tourico_region_world.emulti_city_region_id
			END
		),
		tourico_region_world.ecity_region_id = (
			CASE 
				WHEN destination.RegionType = 'City' THEN destination.desId
				ELSE tourico_region_world.ecity_region_id
			END
			),
		tourico_region_world.eneighbor_region_id = (
			CASE 
				WHEN destination.RegionType = 'Neighborhood' THEN destination.desId
				ELSE tourico_region_world.eneighbor_region_id
			END
			)
WHERE tourico_region_world.id = tourico_region_world_id
		AND destination.desId = desId;
		
end if;


END;

