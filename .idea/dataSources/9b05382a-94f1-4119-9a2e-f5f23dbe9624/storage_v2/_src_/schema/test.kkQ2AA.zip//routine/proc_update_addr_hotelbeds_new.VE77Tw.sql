create procedure proc_update_addr_hotelbeds_new(IN hotelbeds_isoCode varchar(8), IN destination_countryId int(3))
  BEGIN
			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.loc_emulti_region_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.zoneName), ',%')
			AND hotelbeds_map_zone_world_new.loc_emulti_region_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Multi-Region (within a country)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.emulti_region_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.name), ',%')
			AND hotelbeds_map_zone_world_new.emulti_region_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.loc_emulti_city_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.zoneName), ',%')
			AND hotelbeds_map_zone_world_new.loc_emulti_city_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Multi-City (Vicinity)'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.emulti_city_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.name), ',%')
			AND hotelbeds_map_zone_world_new.emulti_city_region_id IS NULL;
		
			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.loc_ecity_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.zoneName), ',%')
			AND hotelbeds_map_zone_world_new.loc_ecity_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'City'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.ecity_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.name), ',%')
			AND hotelbeds_map_zone_world_new.ecity_region_id IS NULL;
		
			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.loc_eneighbor_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND ee_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.zoneName), ',%')
			AND hotelbeds_map_zone_world_new.loc_eneighbor_region_id IS NULL;

			UPDATE
				test.hotelbeds_map_zone_world_new,
				(
				SELECT
					destination.desId,
					destination.desName
				FROM hotel_test.destination
				WHERE countryId = destination_countryId 
				AND display in (1,4,5)
				AND destination.RegionType = 'Neighborhood'
				GROUP BY SUBSTRING_INDEX(desName, ',', 1)
				HAVING COUNT(*) = 1
				) t
			SET hotelbeds_map_zone_world_new.eneighbor_region_id = t.desId, hotelbeds_map_zone_world_new.flag = 'JIM_NNN'
			WHERE isoCode = hotelbeds_isoCode 
			AND e_date IS NULL
			AND fc_replaceStr(t.desName) LIKE CONCAT(fc_replaceStr(hotelbeds_map_zone_world_new.name), ',%')
			AND hotelbeds_map_zone_world_new.eneighbor_region_id IS NULL;
END;

