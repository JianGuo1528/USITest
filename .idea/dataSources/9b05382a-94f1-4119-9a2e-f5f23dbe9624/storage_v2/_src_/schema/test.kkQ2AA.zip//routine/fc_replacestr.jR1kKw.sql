create function fc_replaceStr(str varchar(1000))
  returns varchar(1000)
  BEGIN

DECLARE sstr VARCHAR(1000);
	-- U.S.A.
	SELECT REPLACE(str, ' Area', '') INTO sstr;
	SELECT REPLACE(sstr, ' area', '') INTO sstr;
	SELECT REPLACE(sstr, ' City', '') INTO sstr;
	SELECT REPLACE(sstr, ' city', '') INTO sstr;
	SELECT REPLACE(sstr, 'Saint ', 'St. ') INTO sstr;
	SELECT REPLACE(sstr, ' ', '') INTO sstr;
	
	SELECT REPLACE(REPLACE(REPLACE(sstr, '-', ' '), '.', ''), '\'' ,'') INTO sstr;

	-- Korea
	-- SELECT REPLACE(REPLACE(REPLACE(REPLACE(sstr, ' gun', ''), ' si', ''), ' Si', ''), ' Gwangyeogsi', '') INTO sstr;
	-- SELECT SUBSTRING_INDEX(sstr,'-',1) INTO sstr;
RETURN sstr;
END;

