create function getParentList(rootId int)
  returns varchar(1000)
  BEGIN
      DECLARE sChildList VARCHAR(1000);
      DECLARE sChildTemp VARCHAR(1000);
      SET sChildTemp =cast(rootId as CHAR);
      WHILE sChildTemp is not null DO
        IF (sChildList is not null) THEN
          SET sChildList = concat(sChildList,',',sChildTemp);
    ELSE
      SET sChildList = concat(sChildTemp);
    END IF;
        SELECT group_concat(Parent_RegionID) INTO sChildTemp FROM expedia_region_canada where FIND_IN_SET(RegionID,sChildTemp)>0;
      END WHILE;
      RETURN sChildList;
	 
 
    END;

