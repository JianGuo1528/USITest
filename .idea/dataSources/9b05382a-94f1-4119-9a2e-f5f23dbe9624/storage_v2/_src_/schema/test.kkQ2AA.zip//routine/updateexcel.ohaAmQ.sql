create procedure updateExcel(IN scene int, IN url varchar(255), IN page varchar(32), IN total int)
  BEGIN
	DECLARE i INT;
	SET i = 2;
	WHILE i <= total DO
		INSERT INTO test.ba VALUES 
			(scene, 
			REPLACE(url, 'pn=1', CONCAT('pn=', i)),
			page,
			total);
		SET i = i + 1;
	END WHILE;
END;

