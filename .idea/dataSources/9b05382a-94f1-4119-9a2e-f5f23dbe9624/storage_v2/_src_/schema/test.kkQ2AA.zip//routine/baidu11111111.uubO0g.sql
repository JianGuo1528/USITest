create procedure baidu11111111()
  BEGIN

declare i int;  

  
 
  		    set i = 1;  
        while i <= 46070 do  
						 insert into Content_copy1  (id) VALUES 
						( i);
             set i = i + 1;  
        end while;
				
    COMMIT; -- 提交事务  
 



 
END;

