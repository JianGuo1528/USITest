create procedure baidu()
  BEGIN

declare i int;  
declare V_NUM int;  
declare V_PID  VARCHAR(255);  


DECLARE done INT DEFAULT FALSE; -- 自定义控制游标循环变量,默认false  
  
DECLARE My_Cursor CURSOR FOR (		

		SELECT  ceil(page) page ,city from `baidu-city_景点页数`


); -- 定义游标并输入结果集  
DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE; -- 绑定控制变量到游标,游标循环结束自动转true  
  
delete from TTT;

OPEN My_Cursor; -- 打开游标  
  myLoop: LOOP -- 开始循环体,myLoop为自定义循环名,结束循环时用到  
    FETCH My_Cursor into V_NUM,V_PID; -- 将游标当前读取行的数据顺序赋予自定义变量12 
	
    IF done THEN -- 判断是否继续循环  
      LEAVE myLoop; -- 结束循环  
    END IF;  
    -- 自己要做的事情,在 sql 中直接使用自定义变量即可  
 
  		    set i = 1;  
        while i <= V_NUM do  
						 insert into TTT  (name) VALUES 
						( concat('http://lvyou.baidu.com/destination/ajax/jingdian?format=ajax&cid=0&playid=0&seasonid=5&surl=',V_PID,'&pn=',i,'&rn=18'));
             set i = i + 1;  
        end while;
				
    COMMIT; -- 提交事务  
  END LOOP myLoop; -- 结束自定义循环体  
  CLOSE My_Cursor; -- 关闭游标  



 
END;

