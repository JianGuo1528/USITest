create procedure match_giata_data_new(IN giataTableName varchar(128), IN mapHotelTableName varchar(128))
  BEGIN
	SET @my_query = CONCAT
	(
	'DELETE
	FROM ', giataTableName,
	' WHERE provider = \'117Book\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'DELETE
	FROM ', giataTableName,
	' WHERE (provider, hotelPId) IN
		(SELECT 
		provider,
		hotelPId
		FROM (SELECT provider, hotelPId FROM ', giataTableName, ' GROUP BY provider, hotelPId HAVING count(*) > 1) t1)
	AND giataId NOT IN
		(SELECT
		*
		FROM (SELECT MAX(giataId) FROM ', giataTableName, ' GROUP BY provider, hotelPId HAVING count(*) > 1) t2)
	');
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	-- update hotelIds
	SET @my_query = CONCAT
	(
	'UPDATE ',
		giataTableName, ', ', 
		mapHotelTableName,
	' SET ',
		giataTableName, '.hotelId = ', mapHotelTableName, '.hotelId 
	WHERE
		', giataTableName, '.hotelPId = ', mapHotelTableName, '.hotelPId
	AND ', giataTableName, '.provider = ', mapHotelTableName, '.provider'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'DELETE FROM ', giataTableName, ' WHERE hotelId = 0'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;

	SET @my_query = CONCAT
	(
	'ALTER TABLE ', giataTableName, ' ADD COLUMN priority INT(2) DEFAULT 0'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
	' SET priority = 5
	WHERE provider = \'Expedia\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
	' SET priority = 4
	WHERE provider = \'HotelBeds\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
	' SET priority = 3
	WHERE provider = \'Tourico\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
	' SET priority = 2
	WHERE provider = \'Priceline\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
	' SET priority = 1
	WHERE provider = \'Bonotel\''
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'CREATE TEMPORARY TABLE temp_giata (
		SELECT
			giataId,
			MAX(priority)
		FROM ', giataTableName,
		' GROUP BY giataId
	)'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'UPDATE
		', giataTableName,
		', temp_giata
	SET
		isMain = 1
	WHERE ', giataTableName, '.giataId = temp_giata.giataId
	AND ', giataTableName, '.priority = temp_giata.`MAX(priority)`'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'DROP TABLE temp_giata'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
	SET @my_query = CONCAT
	(
	'ALTER TABLE ', giataTableName, ' DROP COLUMN priority;'
	);
	PREPARE stmt FROM @my_query;
	EXECUTE stmt;
	DEALLOCATE PREPARE stmt;
	
END;

