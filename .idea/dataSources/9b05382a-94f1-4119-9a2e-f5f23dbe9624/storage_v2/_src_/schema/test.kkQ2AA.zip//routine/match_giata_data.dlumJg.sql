create procedure match_giata_data()
  BEGIN
	DELETE
	FROM hotel_test.map_hotel_giata_new_0427
	WHERE provider = '117Book';
	
	DELETE
	FROM hotel_test.map_hotel_giata_new_0427
	WHERE (provider, hotelPId) IN
		(SELECT
		provider,
		hotelPId
		FROM (SELECT provider, hotelPId FROM hotel_test.map_hotel_giata_new_0427 GROUP BY provider, hotelPId HAVING count(*) > 1) t1)
	AND giataId NOT IN
		(SELECT
		*
		FROM (SELECT MAX(giataId) FROM hotel_test.map_hotel_giata_new_0427 GROUP BY provider, hotelPId HAVING count(*) > 1) t2);
		
	ALTER TABLE hotel_test.map_hotel_giata_new_0427 ADD COLUMN priority INT(2) DEFAULT 0;
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427
	SET priority = 5
	WHERE provider = 'Expedia';
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427
	SET priority = 4
	WHERE provider = 'HotelBeds';
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427
	SET priority = 3
	WHERE provider = 'Tourico';
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427
	SET priority = 2
	WHERE provider = 'Priceline';
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427
	SET priority = 1
	WHERE provider = 'Bonotel';
	
	CREATE TEMPORARY TABLE temp_giata (
		SELECT
			giataId,
			MAX(priority)
		FROM
			hotel_test.map_hotel_giata_new_0427
		GROUP BY giataId
	);
	
	UPDATE
		hotel_test.map_hotel_giata_new_0427,
		temp_giata
	SET
		isMain = 1
	WHERE map_hotel_giata_new_0427.giataId = temp_giata.giataId
	AND map_hotel_giata_new_0427.priority = temp_giata.`MAX(priority)`;
	
	DROP TABLE temp_giata;
	
	ALTER TABLE hotel_test.map_hotel_giata_new_0427 DROP COLUMN priority;
	
END;

