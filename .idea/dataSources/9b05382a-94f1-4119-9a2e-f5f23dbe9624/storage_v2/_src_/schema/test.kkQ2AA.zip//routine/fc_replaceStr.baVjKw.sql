CREATE FUNCTION fc_replaceStr(str VARCHAR(1000))
  RETURNS VARCHAR(1000)
  BEGIN

DECLARE sstr VARCHAR(1000);
		-- U.S.A.
	SELECT REPLACE(sstr, 'Saint ', 'St. ') INTO sstr;
	SELECT REPLACE(sstr, ' ', '') INTO sstr;
	
	SELECT REPLACE(REPLACE(REPLACE(str, '-', ' '), '.', ''), '\'' ,'') INTO sstr;

	-- Korea
	-- SELECT REPLACE(REPLACE(REPLACE(REPLACE(sstr, ' gun', ''), ' si', ''), ' Si', ''), ' Gwangyeogsi', '') INTO sstr;
	-- SELECT SUBSTRING_INDEX(sstr,'-',1) INTO sstr;
RETURN sstr;
END;

