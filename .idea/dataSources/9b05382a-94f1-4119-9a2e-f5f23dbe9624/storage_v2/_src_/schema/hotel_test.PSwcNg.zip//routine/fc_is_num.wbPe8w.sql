create function fc_is_num(p_string varchar(32))
  returns int(4)
  BEGIN
/*检查字符串是否为纯数字*/
/*返回值：1-为纯数字 0-非纯数字*/

   DECLARE iResult INT DEFAULT 0;
   SELECT p_string REGEXP '^[0-9]*$' INTO iResult;
   IF iResult = 1 THEN
    RETURN 1;
   ELSE
     RETURN 0;
   END IF;
END;

