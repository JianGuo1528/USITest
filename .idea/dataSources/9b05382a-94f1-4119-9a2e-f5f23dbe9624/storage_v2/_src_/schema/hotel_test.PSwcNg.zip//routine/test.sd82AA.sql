CREATE PROCEDURE test()
  Block1:BEGIN
	#Routine body goes here...
DECLARE num_rows INT;
DECLARE num_rows1 INT;
DECLARE i INT;
DECLARE i1 INT;
DECLARE hotel_id INT;
DECLARE data_now DATE DEFAULT NOW();
DECLARE col_name VARCHAR(50);


DECLARE amenity CURSOR FOR
  SELECT a.hotelId
  FROM expedia_amenity a
  WHERE a.hotelId is not null;

open amenity;
select FOUND_ROWS() into num_rows1;



SET i1=1;
the_loop1: LOOP
   IF i1 > num_rows1 THEN
        CLOSE amenity;
        LEAVE the_loop1;
    END IF;
    FETCH amenity 
    INTO hotel_id; 
Block2:BEGIN
DECLARE col_names CURSOR FOR
  SELECT column_name
  FROM INFORMATION_SCHEMA.COLUMNS
  WHERE table_name = 'expedia_amenity' AND COLUMN_NAME LIKE '%Amenity%'
  ORDER BY ordinal_position;
open col_names;
select FOUND_ROWS() into num_rows;
SET i = 1;
the_loop: LOOP

   IF i > num_rows THEN
        CLOSE col_names;
        LEAVE the_loop;
    END IF;


    FETCH col_names 
    INTO col_name;     

     #do whatever else you need to do with the col name
    set @s = CONCAT('insert hotel_facility(hotelId,productId,title,type,val,fee,provider,type_zh,title_zh,val_zh,created_at,updated_at)
select a.hotelId,null,a.`',col_name,'`,\'Facilities\',null,0,\'Expedia\',\'其他设施\',null,null,NOW(),NOW() from expedia_amenity a where a.hotelId = ',hotel_id,' and a.`',col_name,'`!=\'\'');
		#select @s;
		#select (col_name) from expedia_amenity a where a.hotelId = 1048186; 
		PREPARE stmt from @s;
		EXECUTE stmt;
    SET i = i + 1;  
END LOOP the_loop;
END Block2;
set i1=i1+1;
END LOOP the_loop1;
END Block1;

