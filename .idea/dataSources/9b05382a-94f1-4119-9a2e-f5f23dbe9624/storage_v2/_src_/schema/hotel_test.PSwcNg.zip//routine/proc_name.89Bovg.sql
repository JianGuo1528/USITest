CREATE PROCEDURE proc_name()
  BEGIN

    DECLARE c int ;          
    SET c = 1 ;                     
    WHILE c < 2 DO
        SELECT * FROM room as a WHERE a.id =c ;
      SET c = c + 1 ;
    END WHILE ;

END;

