create procedure proc_name1()
  BEGIN

    DECLARE c int ;                     
    SET c = 1 ;                         
    WHILE c<700 DO
       select * 
       from room  as a 
       WHERE a.id= c;
      
       set c = c + 1 ;

    END WHILE ;

END;

