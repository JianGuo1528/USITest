create function cacuDis(lat1 double, lng1 double, lat2 double, lng2 double)
  returns double
  BEGIN  
    RETURN round(6378.138*2*asin(sqrt(pow(sin( (lat1*pi()/180-lat2*pi()/180)/2),2)+cos(lat1*pi()/180)*cos(lat2*pi()/180)* pow(sin( (lng1*pi()/180-lng2*pi()/180)/2),2)))*1000);  
END;

